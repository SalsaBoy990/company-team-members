<?php
// cannot put this into class due to using traits
define('AG_COMPANY_TEAM_PLUGIN_DIR', plugin_dir_path(__FILE__));
