<?php

// constants
require_once 'constants.php';

// require autoloader
require_once 'autoload.php';


