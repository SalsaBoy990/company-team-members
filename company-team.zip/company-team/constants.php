<?php

// cannot put this into class due to using traits
define('AG_COMPANY_TEAM_PLUGIN_DIR', plugin_dir_path(__FILE__));

define ("AG_COMPANY_TEAM_DEBUG", "1");  // 0 = NO debug output
// 1 = screen output of debug statements
define ("AG_COMPANY_TEAM_LOGGING", "1");  // 0 = NO log output