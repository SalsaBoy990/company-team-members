<?php

define('AG_COMPANY_TEAM_DEBUG', 0);

define('AG_COMPANY_TEAM_LOGGING', 1);

define('AG_COMPANY_TEAM_PLUGIN_DIR', plugin_dir_path(__FILE__));
